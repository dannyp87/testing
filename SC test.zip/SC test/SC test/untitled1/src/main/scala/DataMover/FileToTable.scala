package DataMover


import DataMover.ETLFramework.{DelimitedFileReader, ETlHelper, HiveTableWriter}
import DataMover.ETLFramework.Models.ConfigData
import org.apache.spark.sql.SparkSession

object FileToTable {

  /*def MoveFilesToTable(configData: ConfigData, sparkSession: SparkSession) = {

    val fullSchame = ETlHelper.createSchemaForDF(configData.allCoulmns.split(","))
    val df = DelimitedFileReader.readFile(configData.source, configData.inDelimiter, Option(fullSchame), sparkSession)
    df.show
    val addColumns = configData.addColumns.split(",").map(x => { val data = x.split(":"); (data(0), data(1))}).toMap
    val addedDf = ETlHelper.addColumn(df, addColumns)

    val selectedDf = ETlHelper.selectRequiredColumns(configData.selectColumns.split(","), addedDf)

    HiveTableWriter.fileWrite(selectedDf, configData.outDBName, configData.outTableName)


  }*/

  def MoveFilesToTable(configData: ConfigData, sparkSession: SparkSession) = {
    val fullSchame = ETlHelper.createSchemaForDF(configData.all_schema.split(","))
    val df = DelimitedFileReader.readFile(configData.src_path, configData.src_read_value, Option(fullSchame), sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, configData.add_schema.split(",").map(_.split(":")).map(x => (x(0), x(1))).toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(configData.select_schema.split(","), addedDf)
    HiveTableWriter.fileWrite(selectedDf, configData.tgt_path)
  }

}
