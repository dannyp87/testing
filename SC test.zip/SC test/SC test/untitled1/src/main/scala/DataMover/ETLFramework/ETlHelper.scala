package DataMover.ETLFramework

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{StringType, StructType}
import  org.apache.spark.sql.functions._
import  org.apache.spark.sql.functions
object ETlHelper {

  def selectRequiredColumns(selectColumns:Array[String], dataFrame:DataFrame) : DataFrame = {
    dataFrame.selectExpr(selectColumns:_*)
  }

  def addColumn(dataFrame: DataFrame, columns:Map[String, String]) : DataFrame = {
    columns.foldLeft(dataFrame)((dataFrame, column) => dataFrame.withColumn(column._1 , lit(column._2)) )
  }

  def renameColumn(dataFrame: DataFrame,  columns:Map[String, String]) : DataFrame = {
    columns.foldLeft(dataFrame)((dataFrame, column) => dataFrame.withColumnRenamed(column._1 , column._2))
  }

  def createSchemaForDF(columns:Array[String]) : StructType = {
    val schema = new StructType()
    columns.foldLeft(schema)((schema, column) => schema.add(column, StringType))
  }

  //getData(abcd.selectExpr("HIGHEST_KEY.*"), "HIGHEST_KEY", "")
  //getData(abcd, "")

  val columns : scala.collection.mutable.ArrayBuffer[String] = new scala.collection.mutable.ArrayBuffer()
  import org.apache.spark.sql.DataFrame
  import  org.apache.spark.sql.functions
  def getData( mainDf : DataFrame, tracking_path_p:String) : Unit = {
    for(col <- mainDf.schema) {
      val dtype = col.dataType.simpleString
      if (dtype.toLowerCase.startsWith("struct<")) {
       val tracking_path =  tracking_path_p + "." + col.name
        val current_path =   col.name + ".*"
        getData(mainDf.selectExpr(current_path), tracking_path)
      }
      else if (dtype.toLowerCase.startsWith("array<")) {
        val tracking_path =  tracking_path_p + "." + col.name + "[0]"
         getData(mainDf.select(explode(functions.col(col.name))), tracking_path)
      }
      else {
        var new_naME = ""
        if (tracking_path_p.isEmpty) new_naME = col.name
        else new_naME =  tracking_path_p + "." + col.name
        println("----"+ new_naME.replace(".col.", "."))
        columns.append(new_naME)
      }
    }
  }


  def getget(df:DataFrame, columns:String) = {
    val ll  = columns.split(".")
    if (ll.size > 1) {
      val currentcol = ll(0)
      if (!currentcol.contains("[0]")){
        df.selectExpr("id", currentcol + ".*")
      }
      else {
        df.select(functions.col("id"), functions.explode(functions.col("currentcol")))
      }
    }
  }
  def getData1(df:DataFrame, col_name:String, col_name1:String,  mainDf : DataFrame) : Int = {

    //println("kkkkkkkkkkkkkkkkkkkkkkkk " + col_name1)
    val ddf = mainDf.selectExpr(col_name1)
    //ddf.printSchema()
    //println("?????????????????????????????\n" + ddf.schema.size)
    ddf.schema.foreach(_.name)
    for(col <- ddf.schema) {
      val dtype = col.dataType.simpleString
      if (dtype.toLowerCase.startsWith("struct<")) {
        //println("********************" + col + "LLLLLLLLLLLLLLLLL" + col.name)
        val new_col_name = dtype.split(":")(0).replace("struct<", "").trim
        val new_naME =  col_name + "." + col.name
        val new_naME1 =  col_name + "." + col.name + ".*"
        //println("PPPPPPPPPPPPPPP" + new_naME)
        //println("PPPPPPPPPPPPPPP" + new_naME1)
        val nnnn = getData1(mainDf.selectExpr(new_naME), new_naME, new_naME1, mainDf)
      }
      else if (dtype.toLowerCase.startsWith("array<")) {
        //println("********************" + col + "LLLLLLLLLLLLLLLLL" + col.name)
        val new_col_name = dtype.split(":")(0).replace("struct<", "").trim
        val new_naME =  col_name + "." + col.name + "[0]"
        val new_naME1 =  col_name + "." + col.name + "[0]"
        //println("PPPPPPPPPPPPPPP" + new_naME)
        //println("PPPPPPPPPPPPPPP" + new_naME1)
        val nnnn = getData1(mainDf.selectExpr(new_naME), new_naME, new_naME1, mainDf)
      }
      else {
        val new_naME =  col_name + "." + col.name
        println("-----------------------"+ new_naME)
      }
    }

    return  100
  }
}
