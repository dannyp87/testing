package DataMover.ETLFramework

import org.apache.spark.sql.DataFrame

object HiveTableWriter {

  def fileWrite(dataFrame: DataFrame, dbname:String) = {
    dataFrame.write.insertInto(s"$dbname")
  }

}
