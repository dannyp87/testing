package DataMover

import DataMover.ETLFramework.Models.{ConfigData, ConfigData1}
import Utilities.Helpers
import com.typesafe.config._

class ConfigFileReader {

  def ReadConfigData(config: Config) : ConfigData = {

    val movetype = config.getString("move_type")
    if(movetype == "dfiletodfile")
      readdtod(config)
    else if (movetype == "dfiletofwfile")
      readdtofw(config)
    else if (movetype == "fwfiletodfile")
      readfwdtod(config)
    else if (movetype == "fwfiletofwfile")
    readfwdtofw(config)
    else
      null
  }


  def readdtod(config: Config) : ConfigData  = {

    val fileid = config.getString("fileid")
    val move_type = config.getString("move_type")
    val src_path = config.getString("src_path")
    val  tgt_path = config.getString("tgt_path")
    val  direct_move = config.getString("direct_move").trim() == "True"
    val  src_in_local = config.getString("src_in_local").trim() == "True"
    val  tgt_in_local =  config.getString("tgt_in_local").trim() == "True"
    val  source_header = config.getString("source_header").trim() == "True"
    val  target_header = config.getString("write_header").trim() == "True"
    val  src_read_value = config.getString("src_delimiter")
    val all_schema = config.getString("all_schema")
    val add_schema = config.getString("add_schema")
    val select_schema = config.getString("select_schema")
    val filter_condition= config.getString("filter_condition")
    val tgt_write_value = config.getString("tgt_delimiter")
    val edgenode_path = config.getString("edgenode_path")

    val  readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,
      tgt_in_local, source_header,target_header,src_read_value,all_schema,add_schema,select_schema,
      filter_condition,tgt_write_value, edgenode_path)
     readData
  }

  def readdtofw(config: Config) : ConfigData  = {
    val fileid = config.getString("fileid")
    val move_type = config.getString("move_type")
    val src_path = config.getString("src_path")
    val  tgt_path = config.getString("tgt_path")
    val  direct_move = config.getString("direct_move").trim() == "True"
    val  src_in_local = config.getString("src_in_local").trim() == "True"
    val  tgt_in_local =  config.getString("tgt_in_local").trim() == "True"
    val  source_header = config.getString("source_header").trim() == "True"
    val  target_header = config.getString("write_header").trim() == "True"
    val  src_read_value = config.getString("src_delimiter")
    val all_schema = config.getString("all_schema")
    val add_schema = config.getString("add_schema")
    val select_schema = config.getString("select_schema")
    val filter_condition= config.getString("filter_condition")
    val tgt_write_value = config.getString("tgt_column_width")
    val edgenode_path = config.getString("edgenode_path")

    val  readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,
      tgt_in_local, source_header,target_header,src_read_value,all_schema,add_schema,select_schema,
      filter_condition,tgt_write_value, edgenode_path)
    readData
  }

  def readfwdtod(config: Config) : ConfigData  = {
    val fileid = config.getString("fileid")
    val move_type = config.getString("move_type")
    val src_path = config.getString("src_path")
    val  tgt_path = config.getString("tgt_path")
    val  direct_move = config.getString("direct_move").trim() == "True"
    val  src_in_local = config.getString("src_in_local").trim() == "True"
    val  tgt_in_local =  config.getString("tgt_in_local").trim() == "True"
    val  source_header = config.getString("source_header").trim() == "True"
    val  target_header = config.getString("write_header").trim() == "True"
    val  src_read_value = config.getString("src_column_width")
    val all_schema = config.getString("all_schema")
    val add_schema = config.getString("add_schema")
    val select_schema = config.getString("select_schema")
    val filter_condition= config.getString("filter_condition")
    val tgt_write_value = config.getString("tgt_delimiter")
    val edgenode_path = config.getString("edgenode_path")

    val  readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,
      tgt_in_local, source_header,target_header,src_read_value,all_schema,add_schema,select_schema,
      filter_condition,tgt_write_value, edgenode_path)
    readData
  }

  def readfwdtofw(config: Config) : ConfigData  = {
    val fileid = config.getString("fileid")
    val move_type = config.getString("move_type")
    val src_path = config.getString("src_path")
    val  tgt_path = config.getString("tgt_path")
    val  direct_move = config.getString("direct_move").trim() == "True"
    val  src_in_local = config.getString("src_in_local").trim() == "True"
    val  tgt_in_local =  config.getString("tgt_in_local").trim() == "True"
    val  source_header = config.getString("source_header").trim() == "True"
    val  target_header = config.getString("write_header").trim() == "True"
    val  src_read_value = config.getString("src_column_width")
    val all_schema = config.getString("all_schema")
    val add_schema = config.getString("add_schema")
    val select_schema = config.getString("select_schema")
    val filter_condition= config.getString("filter_condition")
    val tgt_write_value = config.getString("tgt_column_width")
    val edgenode_path = config.getString("edgenode_path")

    val  readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,
      tgt_in_local, source_header,target_header,src_read_value,all_schema,add_schema,select_schema,
      filter_condition,tgt_write_value, edgenode_path)
    readData
  }

}
