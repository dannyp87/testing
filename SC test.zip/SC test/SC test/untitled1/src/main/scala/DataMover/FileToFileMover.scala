package DataMover

import DataMover.ETLFramework.{DelimitedFileReader, DelimitedFileWriter, ETlHelper, FixFileReader}
import DataMover.ETLFramework.Models.{ConfigData, FixFileWriter}
import org.apache.spark.sql.SparkSession

object FileToFileMover {


  def MoveFiles1(sourceDelimitedFile: SourceDelimitedFile, targetDelimitedFile: TargetDelimitedFile, sparkSession: SparkSession) = {

    val fullSchame = ETlHelper.createSchemaForDF(sourceDelimitedFile.allColumns)
    val df = DelimitedFileReader.readFile(sourceDelimitedFile.path, sourceDelimitedFile.delimiter, Option(fullSchame), sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, sourceDelimitedFile.addColumns.toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(sourceDelimitedFile.selectColumns, addedDf)
    DelimitedFileWriter.fileWrite(selectedDf, targetDelimitedFile.delimiter, targetDelimitedFile.path)
  }

  def MoveDtoD(configData: ConfigData, sparkSession: SparkSession)  = {
    val fullSchame = ETlHelper.createSchemaForDF(configData.all_schema.split(","))
    val df = DelimitedFileReader.readFile(configData.src_path, configData.src_read_value, Option(fullSchame), sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, configData.add_schema.split(",").map(_.split(":")).map(x => (x(0), x(1))).toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(configData.select_schema.split(","), addedDf)
    DelimitedFileWriter.fileWrite(selectedDf, configData.tgt_writer, configData.tgt_path)
  }

  def MoveDtoFw(configData: ConfigData, sparkSession: SparkSession) = {
    val fullSchame = ETlHelper.createSchemaForDF(configData.all_schema.split(","))
    val df = DelimitedFileReader.readFile(configData.src_path, configData.src_read_value, Option(fullSchame), sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, configData.add_schema.split(",").map(_.split(":")).map(x => (x(0), x(1))).toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(configData.select_schema.split(","), addedDf)
    FixFileWriter.MoveData(selectedDf, configData)
  }

  def MoveFwtoD(configData: ConfigData, sparkSession: SparkSession) = {
    val df = FixFileReader.readFiexedFilePatter(configData, sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, configData.add_schema.split(",").map(_.split(":")).map(x => (x(0), x(1))).toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(configData.select_schema.split(","), addedDf)
    DelimitedFileWriter.fileWrite(selectedDf, configData.tgt_writer, configData.tgt_path)
  }

  def MoveFWtoFW(configData: ConfigData, sparkSession: SparkSession) : Unit = {
    val df = FixFileReader.readFiexedFilePatter(configData, sparkSession)
    df.show

    val addedDf = ETlHelper.addColumn(df, configData.add_schema.split(",").map(_.split(":")).map(x => (x(0), x(1))).toMap)
    val selectedDf = ETlHelper.selectRequiredColumns(configData.select_schema.split(","), addedDf)
    FixFileWriter.MoveData(selectedDf, configData)
  }
}
