package DataMover.ETLFramework.Models

case class ConfigData1(file_id:String,
                      sourceType:String,
                      destinationType:String,
                      source:String,
                      destination:String,
                      fileType:String,
                      inDelimiter:String,
                      outDelimiter:String,
                      inDBName:String,
                      inTableName:String,
                      outDBName:String,
                      outTableName:String,
                      allCoulmns:String,
                      selectColumns:String,
                      addColumns:String,
                      activeFlag:String)

case class ConfigData(
                      fileid:String,
                      movetype:String,
                      src_path:String,
                      tgt_path:String,
                      direct_move:Boolean,
                      src_in_local:Boolean,
                      tgt_in_local:Boolean,
                      source_header:Boolean,
                      write_header:Boolean,
                      src_read_value:String,
                      all_schema:String,
                      add_schema:String,
                      select_schema:String,
                      filter_condition:String,
                      tgt_writer:String,
                      edgenode_path:String
                      )

