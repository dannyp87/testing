package DataMover.ETLFramework

import DataMover.ETLFramework.Models.ConfigData
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.io.Source

object FixFileReader extends  Serializable {

  def readFiexedFilePatter(configData: ConfigData, spark:SparkSession) : Dataset[Row] = {

    val fixedFilePattern = getColumns(configData)
    val df = getDataFrame(configData.src_path, spark, fixedFilePattern)
    df
  }

  def getRow(row: String, allSchema: List[FiexedPattern]): Row = {
    val columns: scala.collection.mutable.ArrayBuffer[String] = new scala.collection.mutable.ArrayBuffer[String]()
    allSchema.foreach(x => {
      columns.append(row.substring(x.startIndex - 1, x.endIndex).trim())
    })

    Row.fromSeq(columns)
  }

  def getDataFrame(filePath: String, spark: SparkSession, allColumnsRanges:Array[(String, (Int, Int))]): DataFrame = {

    import spark.implicits._

    val allSchema = allColumnsRanges.filter(x => !x.equals("")).
      map(x => {
        FiexedPattern(x._1.trim, x._2._1, x._2._2)
      }).toList

    val fields = allSchema
      .map(field => StructField(field.columnName, StringType, true))
    val schema = StructType(fields)

    val ds = spark.read.textFile(filePath)
    val allRows = ds.rdd.map(x => getRow(x, allSchema))
    val df = spark.createDataFrame(allRows, schema)
    df
  }

  def getColumns(configData: ConfigData)  = {
    val allColumnssizes = configData.tgt_writer.split(",")
      .map(x => {val k = x.split("-");
        (k(0).toInt, k(1).toInt)})
    val allcolumnsNames = configData.all_schema.split(",")
    val allColumns = allcolumnsNames.zip(allColumnssizes)
    allColumns
  }
}

case class FiexedPattern(columnName:String, startIndex:Int,endIndex:Int)
