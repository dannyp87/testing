package DataMover.ETLFramework

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{IntegerType, StringType, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object HiveTableReader {

  def main(args: Array[String]): Unit = {

  }

  def ReadTable(dbName:String, tableName:String, spark:SparkSession) : DataFrame = {
    val df = spark.read.table(s"$dbName.$tableName")
    df
  }

  def ReadTable(dbName:String, tableName:String, spark:SparkSession, schema:StructType) : DataFrame = {
    val df = spark.read.schema(schema).table(s"$dbName.$tableName")
    df
  }

  def ReadTable1(dbName:String, tableName:String, spark:SparkSession, schema:StructType) : DataFrame = {
    import spark.implicits._
    val l5PatentEventMeasure = spark.read.schema(schema).table(s"$dbName.$tableName")
    val l5DictMeasure = spark.read.schema(schema).table(s"$dbName.$tableName")
    val l4Timeframe= spark.read.schema(schema).table(s"$dbName.$tableName")

    val joinedData =  l5PatentEventMeasure.as("pev")
      .join(l5DictMeasure.as("dm"), $"pev.measure_id" === $"dm.measure_id")
      .join(l4Timeframe.as("t"), $"pev.timeframe_id" === $"t.timeframe_id")
      .select(
        $"measure_set",
        $"measure_vers",
        $"pev.timeframe_id",
        $"t.end_dt",
        $"timeframe_type",
        $"timeframe_desc"
      ).distinct()

    val t1 =  joinedData
      .select(
        $"measure_set",
        $"measure_vers",
        $"timeframe_id",
        $"end_dt",
        $"timeframe_type",
        $"timeframe_desc",
          row_number().over(
          Window.partitionBy($"measure_set",$"measure_vers",$"timeframe_type").orderBy($"end_dt".desc)
        ).alias("t_rank")
      )

    t1
      .select(
        row_number().over(
          Window.orderBy($"measure_set".desc,$"measure_vers".desc,$"timeframe_desc".desc)
        ).as("measure_set_id"),
        $"measure_set",
        $"measure_vers",
        $"timeframe_id",
        concat($"measure_set",lit("-"),$"measure_vers",lit(": "),$"timeframe_desc").as("measure_set_timeframe"),
        row_number().over(
          Window.orderBy($"measure_set".desc,$"measure_vers".desc,$"timeframe_desc".desc)
        ).as("prompt_rank")
      )
      .where(
        ($"measure_set".isin(lit("HEDIS"),lit("ACO")) && $"t_rank" <= lit(2)) ||
          ($"".isin(lit("EBM"),lit("EBM-II")) && lit(1))
      )
  }
}
