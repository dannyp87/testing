package DataMover.ETLFramework.Models

import org.apache.spark.sql.{DataFrame, Dataset, functions}

object FixFileWriter {

  def provideAllColumns(dataFrame: DataFrame, columns:Array[(String, (Int, Int))]) = {

    val mapedCols = columns.map(x =>
    functions.rpad(functions.col(x._1), (x._2._2 - x._2._1) + 1, " ").alias(x._1)
    )

     dataFrame.select(mapedCols:_*)
  }

  def concatAllColumns(dataFrame: DataFrame, columns:Array[(String, (Int, Int))]) : Dataset[String] = {
    import dataFrame.sparkSession.implicits._
    val concat = functions.concat_ws("", columns.map(x => functions.col(x._1)) : _*)
    dataFrame.select(concat).as[String]
  }

  def Move(configData: ConfigData)  = {
    val allColumnssizes = configData.tgt_writer.split(",")
      .map(x => {val k = x.split("-");
        (k(0).toInt, k(1).toInt)})
    val allcolumnsNames = configData.all_schema.split(",")
    val allColumns = allcolumnsNames.zip(allColumnssizes)
    allColumns
  }

  def MoveData(dataFrame: DataFrame, configData: ConfigData) = {
    val allColumns = Move(configData)
    val selectDF = provideAllColumns(dataFrame, allColumns)
    val finalDF = concatAllColumns(selectDF, allColumns)
    finalDF.write.text(configData.tgt_path)
  }


}
