package DataMover

import DataMover.ETLFramework.ConfigTableReader
import Utilities.Helpers
import org.apache.spark.sql.SparkSession

object Main {

  def main(args: Array[String]): Unit = {
    val file_Id = "file_1234"
    val config_dbName = ""
    val config_table_name = ""

    //val sparkSession = SparkSession.builder().appName("DataMover").enableHiveSupport().getOrCreate()
    val sparkSession = SparkSession.builder().config("spark.master", "local").appName("DataMover").getOrCreate()

    val config_table_object = new ConfigTableReader(config_dbName, config_table_name, sparkSession)


    val configFileReader = new ConfigFileReader()
    val baseConfig = Helpers.readConfig("TOC_Application.properties", file_Id)
    val configData =  configFileReader.ReadConfigData(config = baseConfig)

    if(configData.movetype == "dfiletodfile")
      FileToFileMover.MoveDtoD(configData, sparkSession)
    else if(configData.movetype == "dfiletofwfile")
      FileToFileMover.MoveDtoFw(configData, sparkSession)
    else if(configData.movetype == "fwfiletodfile")
      FileToFileMover.MoveFwtoD(configData, sparkSession = sparkSession)
    else if(configData.movetype == "fwfiletofwfile")
      FileToFileMover.MoveFWtoFW(configData, sparkSession)

  }
}
