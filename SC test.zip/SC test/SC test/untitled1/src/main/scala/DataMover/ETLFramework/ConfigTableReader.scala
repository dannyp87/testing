package DataMover.ETLFramework

import DataMover.ETLFramework.Models.ConfigData
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

class ConfigTableReader(dbName:String, tableName:String, sparkSession: SparkSession) {

  def validateData(configData: ConfigData) : Boolean  = {

    true
  }
}
