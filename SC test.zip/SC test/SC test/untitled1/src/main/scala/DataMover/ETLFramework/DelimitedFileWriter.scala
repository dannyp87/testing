package DataMover.ETLFramework

import org.apache.spark.sql.DataFrame

object DelimitedFileWriter {

  def fileWrite(dataFrame: DataFrame, delimiter:String, outPath:String) = {
    dataFrame.write.option("sep", delimiter).option("header", "false").csv(outPath)
  }

}
