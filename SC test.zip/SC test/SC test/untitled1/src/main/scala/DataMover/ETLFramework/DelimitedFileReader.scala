package DataMover.ETLFramework

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.StructType

object DelimitedFileReader {

  def readFile(path:String, delimiter:String, schema:Option[StructType], spark:SparkSession) : DataFrame = {
    spark.read.option("sep", delimiter).option("schemainfer", "false").schema(schema.get).csv(path)
  }
}
