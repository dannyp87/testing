package DataMover

case class CommonSource(sourceType:String)
case class SourceDelimitedFile(delimiter:String, path:String, allColumns:Array[String], addColumns:Array[(String, String)], selectColumns:Array[String]) //extends  CommonSource("file")
case class SourceFixFile(path:String, allColumns:Array[(String, Int, Int)], addColumns:Array[(String, String, Int)], selectColumns:Array[(String, Int)]) //extends  CommonSource("file")
case class SourceTable(dbName:String, tableName:String, allColumns:Array[String], addColumns:Array[(String, String)], selectColumns:Array[String]) //extends CommonSource("table")

case class CommonTarget()
case class TargetTable() //extends CommonTarget
case class TargetDelimitedFile(delimiter:String, path:String) //extends  CommonTarget
case class TargetFixFile() //extends CommonTarget
