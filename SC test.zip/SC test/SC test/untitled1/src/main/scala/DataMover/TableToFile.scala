package DataMover

import DataMover.ETLFramework._
import DataMover.ETLFramework.Models.ConfigData
import org.apache.spark.sql.SparkSession

object TableToFile {

  /*def MoveTableToFile(configData: ConfigData, sparkSession: SparkSession) = {

    val fullSchame = ETlHelper.createSchemaForDF(configData.allCoulmns.split(","))
    val df = HiveTableReader.ReadTable(configData.inDBName, configData.inTableName, sparkSession, fullSchame)

    val addColumns = configData.addColumns.split(",").map(x => { val data = x.split(":"); (data(0), data(1))}).toMap
    val addedDf = ETlHelper.addColumn(df, addColumns)

    val selectedDf = ETlHelper.selectRequiredColumns(configData.selectColumns.split(","), addedDf)

    DelimitedFileWriter.fileWrite(selectedDf, configData.outDelimiter, configData.destination)
  }*/
}
