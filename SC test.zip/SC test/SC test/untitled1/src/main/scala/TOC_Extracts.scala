import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.lit
import com.typesafe.config._
import DrugclmFullExtracts.{ClmExtracts, MCEFExtracts, ProfessionalCliamsXML, TransferOutMember}
import Utilities.{FixFileReader, Helpers}
import org.apache.log4j._
import org.apache.spark.SparkConf
import org.apache.spark.sql.expressions.Window


object TOC_Extracts {

  val log = Logger.getLogger(getClass.getName)
  log.setLevel(org.apache.log4j.Level.INFO)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf();
    conf.registerKryoClasses(Array(classOf[FixFileReader]))

    val spark = SparkSession.builder().config(conf).appName("TOC_Extracts").enableHiveSupport().getOrCreate()
    //val spark = SparkSession.builder().appName("TOC_Extracts").config("spark.master", "local").getOrCreate()
    //val lob = args(0)
    //val lob = "Drug_clm"
    val lob = "Drug_clm"
    val baseConfig = Helpers.readConfig("TOC_Application.properties", "TOC")

    runExtractJob(lob, spark, baseConfig)
    //ClmExtracts.commonExtraction(spark, "PW", baseConfig, lob)
  }

  def runExtractJob(lob:String, spark:SparkSession, config: Config) = {

    lob match {
      case "Drug_clm" => {
        drugClmExtrats(spark, config, lob)
        ClmExtracts.commonExtraction(spark, "PW", config, lob)
      }
      case "Profsnl_clm" => {
        profsnlClmExtract(spark, config, lob)
        //ClmExtracts.commonExtraction(spark, "PW", config, lob)
      }
      case _ => "aaaa"
    }
  }

  def drugClmExtrats(spark:SparkSession, config: Config, lob:String) = {

    import spark.implicits._

    val drugClmConfig = config.getConfig(lob)

    val mcefDf = MCEFExtracts.getMCEFDF(spark, drugClmConfig.getString("MCEF_HDFS_DIR"), "2019/12/12", "2019/12/12")

    val file_nm_prep="mcef"
    val rec_insrt_ts = Helpers.getCurrentDateTime("yyyy-MM-dd hh:mm:ss")
    val file_id_type_cd = "X"
    val end_date = "2019-02-27"
    val file_dt = "2019-05-25"

    val extractDF = TransferOutMember.getTransferOutMeberDF(spark, config).select("h_rec_maj_typ_cd",
      "pharm_clm_file_nm", "eff_end_dt", "xfer_to_mco_cd", "mcaid_id", "sub_id", "upd_ts", "rec_insrt_ts")
    val filter_member_df = extractDF.where(s"to_date(eff_end_dt) <= '$end_date' and trim(h_rec_maj_typ_cd) = 'T' and trim(profsnl_clm_file_nm) = ''")


    val joinData = mcefDf.alias("mc").join(filter_member_df.alias("met"), $"mc.sub_id" === $"met.sub_id")
    val drug_clm_SelectStatements = MCEFExtracts.readDrug_Clm_SelectStatements("TOC_Resources/Drug_Clm_Extract_Pattern.txt")

    println(drug_clm_SelectStatements)
    val selectData = joinData.selectExpr( drug_clm_SelectStatements: _*)
      .withColumn("file_dt", lit(file_dt))
       .withColumn("rec_insrt_ts", lit(rec_insrt_ts))
        .withColumn("lob", lit(lob))

   val final_drug_clm_filter_data =  selectData.where(s"datediff(to_date(eff_end_dt), c_mco_enctr_recd_dt) <= 365")

    selectData.show()

    spark.conf.set("hive.exec.dynamic.partition", "true")
    spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    val hiveDBName = drugClmConfig.getString("DB")
    val hiveTableName = drugClmConfig.getString("TABLE")

    final_drug_clm_filter_data.write.mode("append").insertInto(s"$hiveDBName.$hiveTableName")
  }

  def profsnlClmExtract(spark:SparkSession, config: Config, lob:String) = {

    import spark.implicits._

    val profsnlClmConfig = config.getConfig(lob)

    val profsnlClmDF = ProfessionalCliamsXML.GetProfessionalClaimsXMLDF(spark, profsnlClmConfig.getString("MCEF_HDFS_DIR"), "2019/02/01", "2019/02/15")
    //val mcefDf = MCEFExtracts.getMCEFDF(spark, profsnlClmConfig.getString("MCEF_HDFS_DIR"), "2019/12/12", "2019/12/12")

    val file_nm_prep="mcef"
    val rec_insrt_ts = Helpers.getCurrentDateTime("yyyy-MM-dd hh:mm:ss")
    val file_id_type_cd = "X"
    val end_date = "2019-02-28"
    val file_dt = "2019-05-26"

    val extractDF = TransferOutMember.getTransferOutMeberDF(spark, config).select("h_rec_maj_typ_cd",
      "profsnl_clm_file_nm", "eff_end_dt", "xfer_to_mco_cd", "mcaid_id", "sub_id", "upd_ts", "rec_insrt_ts")
    val filter_member_df = extractDF.where(s"to_date(eff_end_dt) <= '$end_date' and trim(h_rec_maj_typ_cd) = 'T' and trim(profsnl_clm_file_nm) = ''")

   val profnl_clm_table_df =  ProfessionalCliamsXML.getFinalDaatSet(spark, profsnlClmDF, filter_member_df)

    spark.conf.set("hive.exec.dynamic.partition", "true")
    spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    val hiveDBName = profsnlClmConfig.getString("DB")
    val hiveTableName = profsnlClmConfig.getString("TABLE")

    val profnl_clm_table_final_df = profnl_clm_table_df.withColumn("file_dt", lit(file_dt)).withColumn("lob", lit(lob))

    val profsnl_final_filter_data = profnl_clm_table_final_df.where(s"datediff(to_date(c_mco_enctr_recd_dt), c_mco_enctr_recd_dt) <= 365")

    profsnl_final_filter_data.show

    //profnl_clm_table_final_df.write.mode("append").insertInto(s"$hiveDBName.$hiveTableName")
  }
}