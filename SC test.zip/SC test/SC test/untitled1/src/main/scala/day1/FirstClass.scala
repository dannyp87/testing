package day1

import scala.annotation.tailrec

object FirstClass {
  // static class

  def main(args:Array[String]) = {

    //print(fact(10))
//    print(face(10, 1))
//    val dd = 100.123
//
//    val op = add_currying(10)(20)
//    op(100)
//    op(200)
//
//    val a = (a:Int) => (b:Int) => a + b
//    a
//
//    val f1 = PAF("raj", _:Int, _:Double)
//    f1(100, 123.123)
//
//    val ob = new Student("raj", "10")
//    val ob1 = new Student("ram", "12")

    def test(x:Int) = {
      x match {
        case 10 => print("ten")
        case 20 => println("twenty")
        case _ => print("other")
      }
    }

    def test1(x:Any) = {
      x match {
        case a:Int if a == 0 => print("integer")
        case d:Double => print("double")
        case s:String => print("string")
      }
    }

    def sum1(li:List[Int]) : Int = {
      li match {
        case a :: Nil => return a
        case a :: b  => return a + sum1(b)
      }
    }

    test(10)
    test1(100)


    //ob.grade = "100"
    // ob.display()
    // ob1.display()

//    var t1 = Teacher("raj", "A")
//    var t3 = t1
//    t1 = Teacher("raj", "B")
//    val t2 = t1.copy()
//    t1.equals(t2)

  }

  def welcone() = {
    println("hello")
  }


  def fact(n:Int) :Int = {
    if (n == 0) {
      throw new Exception("error")
      return  1
    }
    else n * fact(n-1)
  }

  def face(n:Int, value:Int) :Int = {
    if (n == 0)  throw new Exception("error")
    else face(n-1, value * n)
  }

  def PAF(name:String, age:Int, score:Double) = {
    print("hello " + name)
  }

  def add_currying(a:Int)(b:Int)(c:Int) = {
    a + b + c
  }

}



class Student(name:String, var grade:String) {
   def display()  = {
    println("hello" + " "+ name + " " + grade)
     val kk = new A1("raj")
  }
}

case class Teacher(name :String, grade:String)

class A1(val name:String) {
  def test():Int = {
    A1.welcome()
    100
  }
}

object A1 {
  def welcome() = {
    println("hello")
  }
}


trait T1 {
  def test1(a:Int) : Int = a + 100
  def test(a:Int) : Int
}

trait T2 {
  def test3(x:Int) : Int
}
class TT1 extends T1 with T2{
  override def test(a: Int): Int = a
  override def test3(a: Int): Int = {
    val circle1 = new Circle(5.0)
    circle1.area
    circle1(100)
    return 100
  }
}

import scala.math._
 class Circle(radius: Double) {
  def area: Double = Circle.calculateArea(radius)
  def apply(radius: Double): Int = 100
}

object Circle {
  private def calculateArea(radius: Double): Double = Pi * pow(radius, 2.0)
   def calculateArea1(radius: Double): Double = Pi * pow(radius, 2.0)
}



