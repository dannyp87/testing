package DrugclmFullExtracts

import java.text.SimpleDateFormat

import Utilities.Helpers
import com.databricks.spark.xml._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.types.ArrayType

object ProfessionalCliamsXML {

  def GetProfessionalClaimsXMLDF(spark:SparkSession, basePath: String, startDate: String, endDate: String) = {
    import spark.implicits._
    import java.text.SimpleDateFormat
    val sdf = new SimpleDateFormat("yyyy-MM-dd")

    val schema = StructType(Array(
      StructField("CLM",
        StructType(Array(StructField("_CLM_ID",StringType,true),
          StructField("_DCN",StringType,true),
          StructField("_ORIGL_PL_OF_SVC",StringType,true),
          StructField("_PLCY_ID",StringType,true),
          StructField("_RCVD_DT",StringType,true),
          StructField("_VALUE",StringType,true))),
        true),
      StructField("CLM_DETL",StructType(Array(StructField("_CLM_ID",StringType,true),
        StructField("_LST_UPD_DT",StringType,true),
        StructField("_VALUE",StringType,true))),
        true),
      StructField("CLM_ID",StringType,true),
      StructField("EVENT_TYPE",StringType,true),
      StructField("FNLZD_CLM_DIAG",ArrayType(StructType(Array(StructField("_CLM_DIAG_SEQ_NBR",StringType,true),
        StructField("_CLM_DIAG_TYP_CD",StringType,true),
        StructField("_CLM_ID",StringType,true),
        StructField("_CLM_SVC_LN_NBR",StringType,true),
        StructField("_DIAG_CD",StringType,true),
        StructField("_DIAG_PRSNT_ON_ADM_CD",StringType,true),
        StructField("_EXTRNL_INJRY_CAU_POA_IND",StringType,true),
        StructField("_HCSC_DIC_CD",StringType,true),
        StructField("_LVL_OF_IMPRTNC",StringType,true),
        StructField("_NARTV_TXT",StringType,true),
        StructField("_RCVD_DT",StringType,true),
        StructField("_SVC_DIAG_PNTR_NBR",StringType,true),
        StructField("_SYM_PRSNT_ON_ADM_IND",StringType,true),
        StructField("_VALUE",StringType,true))),
        true),true),
      StructField("FNLZD_CLM_PROV",ArrayType(StructType(Array(StructField("_CLM_ID",StringType,true),
        StructField("_NPI",StringType,true),
        StructField("_ORGZN_NM",StringType,true),
        StructField("_PROV_FUNC_CD",StringType,true),
        StructField("_VALUE",StringType,true))),
        true),true),
      StructField("FNLZD_CSL",ArrayType(StructType(Array(StructField("_ACCOM_RT_AMT",StringType,true),
        StructField("_ACTL_AMB_MILE_CNT",StringType,true),
        StructField("_ADDNL_SVC_ITM_CD",StringType,true),
        StructField("_ANES_SVC_HR_CNT",StringType,true),
        StructField("_ANES_SVC_MN_CNT",StringType,true),
        StructField("_ANES_UNIT_CNT",StringType,true),
        StructField("_BIS_ASGND_LN_ITM_NBR",StringType,true),
        StructField("_CCP_CNT",StringType,true),
        StructField("_CLM_ID",StringType,true),
        StructField("_COMBD_SVC_LN_CNT",StringType,true),
        StructField("_CPAY_AMT",StringType,true),
        StructField("_DT_IND",StringType,true),
        StructField("_DUPLCT_DCN",StringType,true),
        StructField("_EPP_XREF_SVC_ID_CD",StringType,true),
        StructField("_FNLZD_SVC_LN_NBR",StringType,true),
        StructField("_GOVT_PGM_SVC_CAT_CD",StringType,true),
        StructField("_HCSC_BNFT_CD",StringType,true),
        StructField("_HCSC_COVRG_CAT_CD",StringType,true),
        StructField("_HCSC_DESCR_CD",StringType,true),
        StructField("_HCSC_ILNS_CLSFN_CD",StringType,true),
        StructField("_HCSC_PERFG_PROV_NBR",StringType,true),
        StructField("_HCSC_PERFG_PROV_TYP",StringType,true),
        StructField("_HCSC_PROD_CD",StringType,true),
        StructField("_HCSC_PRVSN_CD",StringType,true),
        StructField("_HCSC_TOS_CD",StringType,true),
        StructField("_HCSC_TRET_LOC",StringType,true),
        StructField("_IC_ALWBL_AMT",StringType,true),
        StructField("_IC_MCARE_PD_AMT",StringType,true),
        StructField("_INCLSV_GRPG_PRIMY_SVC_LN_IND",StringType,true),
        StructField("_MCARE_PD_AMT",StringType,true),
        StructField("_MCARE_SEQTRTN_REDUCTN_AMT",StringType,true),
        StructField("_MENT_HEALTH_IND",StringType,true),
        StructField("_NON_COVD_CHRG_AMT",StringType,true),
        StructField("_ORIGL_BILLED_AMT",StringType,true),
        StructField("_ORIGL_PL_OF_SVC",StringType,true),
        StructField("_ORIGL_SVC_LN_NBR",StringType,true),
        StructField("_PAT_LIAB_AMT",StringType,true),
        StructField("_PRCG_SVC_LN_ORD_CD",StringType,true),
        StructField("_PRL_HCSC_TOS_CD",StringType,true),
        StructField("_PRL_SVC_ITEM_CD",StringType,true),
        StructField("_RCVD_DT",StringType,true),
        StructField("_REF_BAS_PRC_SAVG_AMT",StringType,true),
        StructField("_SCND_PAYR_PD_AMT",StringType,true),
        StructField("_SVC_BEG_DT",StringType,true),
        StructField("_SVC_DAY_CNT",StringType,true),
        StructField("_SVC_END_DT",StringType,true),
        StructField("_SVC_ITEM_CD",StringType,true),
        StructField("_SVC_ITEM_ID",StringType,true),
        StructField("_SVC_LN_INCLSV_GRPG_NBR",StringType,true),
        StructField("_SVC_LN_OVRRD_BY_CLM_IND",StringType,true),
        StructField("_SVC_PERF_BY_SPCLST",StringType,true),
        StructField("_SVC_UNIT_CNT",StringType,true),
        StructField("_SVN_LN_QSTNABL_IND",StringType,true),
        StructField("_VALUE",StringType,true),
        StructField("_XPRT_DSTNC_CNT",StringType,true))),
        true),true),
      StructField("FNLZD_CSL_PROCD_MDFYR",ArrayType(StructType(Array(StructField("_CLM_ID",StringType,true),
        StructField("_FNLZD_SVC_LN_NBR",StringType,true),
        StructField("_MDFYR_CD_SEQ",StringType,true),
        StructField("_SVC_ITM_MDFYR_CD",StringType,true),
        StructField("_VALUE",StringType,true))),
        true),true),
      StructField("RCVD_DT",StringType,true),
      StructField("SRC_LST_UPD_TS",StringType,true)))

    val profsnlAllFiles = Helpers.getFolderNamesBetweenDates(basePath, startDate, endDate)

    //val df = spark.read.format("xml").option("rowTag", "CLAIM").schema(schema).load("C:\\Users\\krajkumar\\Desktop\\HCSC\\TOC\\Phatrmacy\\spark\\xmldata_working.xml")
    val df = spark.read.format("xml").option("rowTag", "CLAIM").option("path", profsnlAllFiles.mkString(",")).schema(schema).load()
    val fds = df.as[Abcd]
    val fsd1 = fds.withColumn("FNLZD_CSL1",explode($"FNLZD_CSL")).drop("FNLZD_CSL").withColumnRenamed("FNLZD_CSL1","FNLZD_CSL").as[Abcd1]
    val dataset = fsd1.map(x => Abcd1(x.CLM, x.CLM_DETL, x.CLM_ID, x.EVENT_TYPE, x.FNLZD_CLM_DIAG, x.FNLZD_CLM_PROV, x.FNLZD_CSL, x.FNLZD_CSL_PROCD_MDFYR.filter(y => y._FNLZD_SVC_LN_NBR == x.FNLZD_CSL._FNLZD_SVC_LN_NBR), x.RCVD_DT, x.SRC_LST_UPD_TS))
    dataset


    //fsd2.write.format("xml").option("rootTag", "books").option("rowTag", "CLAIM").save("C:\\Users\\krajkumar\\Desktop\\HCSC\\TOC\\Phatrmacy\\spark\\xmldata_op.xml")

  }

  def getFinalDaatSet(spark:SparkSession, dataset:Dataset[Abcd1], transfer_out_mbr_df:DataFrame) = {
    import spark.implicits._

    val now = new java.util.Date();
    val  current = new java.sql.Timestamp(now.getTime());
    val sdf = new SimpleDateFormat("yyyy-MM-dd")

    val joinData = dataset.as("ds").join(transfer_out_mbr_df .as("df"), regexp_replace($"ds.CLM._PLCY_ID","^0*", "") === $"sub_id").
      selectExpr("ds.*", "xfer_to_mco_cd as xfer_mco_code").
      withColumn("rec_insrt_ts", lit(current)).as[Abcd2]

    val op = joinData.rdd.map(x => TableData(x.CLM._DCN, x.rec_insrt_ts, "M", "",
      handleFNLZD_CLM_PROV(x.FNLZD_CLM_PROV,"B1", "org"), handleFNLZD_CLM_PROV(x.FNLZD_CLM_PROV,"82","npi"),
      "","","","",
      x.CLM._PLCY_ID.toInt,
      new java.sql.Date(sdf.parse(x.FNLZD_CSL._SVC_BEG_DT).getTime), new java.sql.Date(sdf.parse(x.FNLZD_CSL._SVC_END_DT).getTime), new java.sql.Date(sdf.parse(x.CLM._RCVD_DT).getTime), new java.sql.Date(sdf.parse(x.CLM_DETL._LST_UPD_DT).getTime),
      "","","","","","",
      handleFNLZD_CLM_PROV(x.FNLZD_CLM_PROV,"B1", "org"), "",
      handleSeq_Nbr(x.FNLZD_CSL_PROCD_MDFYR,"1"),handleSeq_Nbr(x.FNLZD_CSL_PROCD_MDFYR,"2"),handleSeq_Nbr(x.FNLZD_CSL_PROCD_MDFYR,"3"),handleSeq_Nbr(x.FNLZD_CSL_PROCD_MDFYR,"4"),
      x.CLM._ORIGL_PL_OF_SVC.toString,
      handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "1"),handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "2"),
      handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "3"),handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "4"),
      handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "5"),handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "6"),
      handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "7"),
      handleFNLZD_CLM_DIAG(x.FNLZD_CLM_DIAG, "8"),
      new java.sql.Date(sdf.parse(x.CLM_DETL._LST_UPD_DT).getTime),
      handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "1"), handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "2"),
      handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "3"),handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "4"),
      handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "5"), handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "6"),
      handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "7"), handleFNLZD_CLM_DIAG1(x.FNLZD_CLM_DIAG, "8"),
      x.FNLZD_CSL._FNLZD_SVC_LN_NBR.toInt,x.FNLZD_CSL._SVC_ITEM_CD.toString," ",
      convertToBigDecimal(x.FNLZD_CSL._SVC_UNIT_CNT) ,convertToBigDecimal("0"),convertToBigDecimal(x.FNLZD_CSL._SVC_DAY_CNT),
      "",
      new java.sql.Date(sdf.parse(x.FNLZD_CSL._SVC_BEG_DT).getTime),new java.sql.Date(sdf.parse(x.FNLZD_CSL._SVC_END_DT).getTime),
      "","")
    ).toDS()
    op
 }

   def handleFNLZD_CLM_DIAG(FNLZD_CLM_DIAG1:Array[FNLZD_CLM_DIAG], value:String) : String = {
    val fdata = FNLZD_CLM_DIAG1.filter(p => p._SVC_DIAG_PNTR_NBR == value)
    if(fdata.size == 1) value else ""
  }

   def handleFNLZD_CLM_DIAG1(FNLZD_CLM_DIAG1:Array[FNLZD_CLM_DIAG], value:String) : String = {
    val fdata = FNLZD_CLM_DIAG1.filter(p => p._CLM_DIAG_SEQ_NBR == value)
    if(fdata.size == 1) fdata.head._DIAG_CD else ""
  }

   def handleSeq_Nbr(data:Array[FNLZD_CSL_PROCD_MDFYR], value:String) : String = {
    val fdata = data.filter(p => p._MDFYR_CD_SEQ == value)
    if(fdata.size == 1) fdata.head._SVC_ITM_MDFYR_CD.toString else ""
  }

   def handleFNLZD_CLM_PROV(FNLZD_CLM_PROV1:Array[FNLZD_CLM_PROV], value:String, get:String) : String = {
    val fdata = FNLZD_CLM_PROV1.filter(p => p._PROV_FUNC_CD == value)
    if(fdata.size == 1 && get == "org") fdata.head._ORGZN_NM
    else if(fdata.size == 1 && value == "npi") fdata.head._NPI.toString
    else ""
  }

   def convertToBigDecimal(value:String) : java.math.BigDecimal = {
    if(value.trim == "") BigDecimal("0").bigDecimal
    else  BigDecimal(value).bigDecimal
  }
}


case class CLM (_CLM_ID:String,_DCN:String,_ORIGL_PL_OF_SVC:String,_PLCY_ID:String,_RCVD_DT:String,_VALUE:String)

case class CLM_DETL (_CLM_ID:String,_LST_UPD_DT:String,_VALUE:String)

case class FNLZD_CLM_DIAG (_CLM_DIAG_SEQ_NBR:String,_CLM_DIAG_TYP_CD:String,_CLM_ID:String,_CLM_SVC_LN_NBR:String,_DIAG_CD:String,
                            _DIAG_PRSNT_ON_ADM_CD:String,_EXTRNL_INJRY_CAU_POA_IND:String,_HCSC_DIC_CD:String,_LVL_OF_IMPRTNC:String,
                            _NARTV_TXT:String,_RCVD_DT:String,_SVC_DIAG_PNTR_NBR:String,_SYM_PRSNT_ON_ADM_IND:String,
                            _VALUE:String)


case class FNLZD_CLM_PROV (_CLM_ID:String,_NPI:String,_ORGZN_NM:String,_PROV_FUNC_CD:String,_VALUE:String)

case class FNLZD_CSL (_ACCOM_RT_AMT:String, _ACTL_AMB_MILE_CNT:String,_ADDNL_SVC_ITM_CD:String,_ANES_SVC_HR_CNT:String,_ANES_SVC_MN_CNT:String,_ANES_UNIT_CNT:String,_BIS_ASGND_LN_ITM_NBR:String,_CCP_CNT:String,_CLM_ID:String,_COMBD_SVC_LN_CNT:String,_CPAY_AMT:String,_DT_IND:String,_DUPLCT_DCN:String,_EPP_XREF_SVC_ID_CD:String,_FNLZD_SVC_LN_NBR:String,_GOVT_PGM_SVC_CAT_CD:String,_HCSC_BNFT_CD:String,_HCSC_COVRG_CAT_CD:String,_HCSC_DESCR_CD:String,_HCSC_ILNS_CLSFN_CD:String,_HCSC_PERFG_PROV_NBR:String,_HCSC_PERFG_PROV_TYP:String,_HCSC_PROD_CD:String,_HCSC_PRVSN_CD:String,_HCSC_TOS_CD:String,_HCSC_TRET_LOC:String,_IC_ALWBL_AMT:String,_IC_MCARE_PD_AMT:String,_INCLSV_GRPG_PRIMY_SVC_LN_IND:String,_MCARE_PD_AMT:String,_MCARE_SEQTRTN_REDUCTN_AMT:String,_MENT_HEALTH_IND:String,_NON_COVD_CHRG_AMT:String,_ORIGL_BILLED_AMT:String,_ORIGL_PL_OF_SVC:String,_ORIGL_SVC_LN_NBR:String,_PAT_LIAB_AMT:String,_PRCG_SVC_LN_ORD_CD:String,_PRL_HCSC_TOS_CD:String,_PRL_SVC_ITEM_CD:String,_RCVD_DT:String,_REF_BAS_PRC_SAVG_AMT:String,_SCND_PAYR_PD_AMT:String,_SVC_BEG_DT:String,_SVC_DAY_CNT:String,_SVC_END_DT:String,_SVC_ITEM_CD:String,_SVC_ITEM_ID:String,_SVC_LN_INCLSV_GRPG_NBR:String,_SVC_LN_OVRRD_BY_CLM_IND:String,_SVC_PERF_BY_SPCLST:String,_SVC_UNIT_CNT:String,_SVN_LN_QSTNABL_IND:String,_VALUE:String,_XPRT_DSTNC_CNT:String)

case class FNLZD_CSL_PROCD_MDFYR (_CLM_ID:String,_FNLZD_SVC_LN_NBR:String,_MDFYR_CD_SEQ:String,_SVC_ITM_MDFYR_CD:String,_VALUE:String)

case class Abcd(CLM:CLM,CLM_DETL:CLM_DETL,CLM_ID:String,EVENT_TYPE:String,FNLZD_CLM_DIAG:Array[FNLZD_CLM_DIAG],
                 FNLZD_CLM_PROV:Array[FNLZD_CLM_PROV],FNLZD_CSL:Array[FNLZD_CSL],FNLZD_CSL_PROCD_MDFYR:Array[FNLZD_CSL_PROCD_MDFYR],
                 RCVD_DT:String,SRC_LST_UPD_TS:String)

case class Abcd1(CLM:CLM,CLM_DETL:CLM_DETL,CLM_ID:String,EVENT_TYPE:String,FNLZD_CLM_DIAG:Array[FNLZD_CLM_DIAG],
                  FNLZD_CLM_PROV:Array[FNLZD_CLM_PROV],FNLZD_CSL:FNLZD_CSL,FNLZD_CSL_PROCD_MDFYR:Array[FNLZD_CSL_PROCD_MDFYR],
                  RCVD_DT:String,SRC_LST_UPD_TS:String)

case class Abcd2(CLM:CLM,CLM_DETL:CLM_DETL,CLM_ID:String,EVENT_TYPE:String,FNLZD_CLM_DIAG:Array[FNLZD_CLM_DIAG],
                 FNLZD_CLM_PROV:Array[FNLZD_CLM_PROV],FNLZD_CSL:FNLZD_CSL,FNLZD_CSL_PROCD_MDFYR:Array[FNLZD_CSL_PROCD_MDFYR],
                 RCVD_DT:String,SRC_LST_UPD_TS:String, rec_insrt_ts:java.sql.Timestamp, xfer_mco_code:String)

//case class TableData(TCN_NBR:String, CLM_TYP_CD:String, BILL_PROV_ID:String, BILL_PROV_NM:String, BILL_NPI_ID:String, BILL_TAXNMY_CD:String, BILL_PROV_TYP_CD:String, BILL_PROV_SPCLTY_CD:String, MC_PROV_ID:String, MC_PROV_NM:String, MCAID_CRD_ID:Int, HDR_FST_SVC_DT:java.sql.Date, HDR_LST_SVC_DT:java.sql.Date, MCO_ENCTR_RCVD_DT:java.sql.Date, PD_DT:java.sql.Date, PLN_NBR:String, PLN_TYP_CD:String, CAT_OF_SVC_CD:String, RNDRG_PROV_ID:String, RNDRG_PROV_NM:String, RNDRG_PROV_TYP_CD:String, RNDRG_PROV_SPCLTY_CD:String, RNDRG_NPI_ID:String, RNDRG_TAXNMY_Cd:String, LN_PROCD_MOD_1_CD:String, LN_PROCD_MOD_2_CD:String, LN_PROCD_MOD_3_CD:String, LN_PROCD_MOD_4_CD:String, PL_OF_SVC_CD:String, DIAG_1_REL_CD:String, DIAG_2_REL_CD:String, DIAG_3_REL_CD:String, DIAG_4_REL_CD:String, DIAG_5_REL_CD:String, DIAG_6_REL_CD:String, DIAG_7_REL_CD:String, DIAG_8_REL_CD:String, MCO_PD_DT:java.sql.Date, DIAG_1_CD:String, DIAG_2_CD:String, DIAG_3_CD:String, DIAG_4_CD:String, DIAG_5_CD:String, DIAG_6_CD:String, DIAG_7_CD:String, DIAG_8_CD:String, LN_NBR:Int, PROCD_CD:String, PROCD_CD_DESC:String, LN_BILL_UNIT_AMT:java.math.BigDecimal, LN_ALWD_UNIT_AMT:java.math.BigDecimal, LN_Pd_UNIT_AMT:java.math.BigDecimal, LN_CAT_OF_SVC_CD:String, LN_SVC_FST_DT:java.sql.Date, LN_SVC_LST_DT:java.sql.Date)
case class TableData(c_tcn_num:String, rec_insrt_ts: java.sql.Timestamp, c_hdr_ty_cd:String, c_bill_prov_id:String,
                     p_srt_nam:String, c_bill_npi_id:String,
                     c_bill_txnmy_cd:String, c_bill_prov_ty:String, c_bill_prov_spec:String, c_mc_prov_id:String,
                     b_alt_id:Int, c_hdr_svc_fst_dt:java.sql.Date, c_hdr_svc_lst_dt:java.sql.Date,
                     c_mco_enctr_recd_dt:java.sql.Date, c_hdr_pd_dt:java.sql.Date, h_pln_num:String, h_pln_ty_cd:String,
                     c_cos_cd:String, c_rndr_prov_id:String, p_rndr_ty_cd:String,
                     p_rndr_spec_cd:String, c_rndr_npi_id:String, c_rndr_txnmy_cd:String, c_proc_mod_cd_1:String,
                     c_proc_mod_cd_2:String, c_proc_mod_cd_3:String, c_proc_mod_cd_4:String, r_pl_of_svc_cd:String,
                     c_diag_1st_rltd_cd:String, c_diag_2nd_rltd_cd:String, c_diag_3rd_rltd_cd:String, c_diag_4th_rltd_cd:String,
                     c_diag_5th_rltd_cd:String,
                     c_diag_6th_rltd_cd:String, c_diag_7th_rltd_cd:String, c_diag_8th_rltd_cd:String, c_mco_pd_dt:java.sql.Date,
                     r_diag_cd_1:String,
                     r_diag_cd_2:String, r_diag_cd_3:String, r_diag_cd_4:String, r_diag_cd_5:String,
                     r_diag_cd_6:String, r_diag_cd_7:String,
                     r_diag_cd_8:String, c_li_num:Int ,r_proc_cd:String, r_proc_shrt_desc:String, c_li_subm_unt_num:java.math.BigDecimal,
                     c_li_alw_unt_num:java.math.BigDecimal, c_li_reimb_unt_num:java.math.BigDecimal, c_li_cos_cd:String,
                     c_li_fst_dos_dt:java.sql.Date, c_li_lst_dos_dt:java.sql.Date, sub_id:String, xfer_mco_code:String)
