package DrugclmFullExtracts

import Utilities.Helpers
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object TransferOutMember {

  def getTransferOutMeberDF(spark:SparkSession, config:Config) = {
    //spark.read.option("header","false").option("inferSchema","false").option("sep","|").csv("")

    val memberExtractDB = config.getString("Member_Extract_DB")
      val memberExtractTable = config.getString("Member_Extract_Table")
    println(s"-------------$memberExtractDB.$memberExtractTable---------------")
    spark.read.table(s"$memberExtractDB.$memberExtractTable")
  }

  def insertIntoTransferOutMemberDF(df:DataFrame, sparkSession: SparkSession, config: Config, lob:String) = {

    import sparkSession.implicits._

    val memberOutViewDBName=config.getString("Member_Extract_VIEWDB")
    val memberOutViewName=config.getString("Member_Extract_VIEW")
    val memberOutTableName=config.getString("Member_Extract_DB")
    val memberOutDBName=config.getString("Member_Extract_Table")

    val lobConfig = config.getConfig(lob)
    val lobHiveDBName=lobConfig.getString("DB")
    val lobHiveTableName=lobConfig.getString("TABLE")


    val fileName = ""

    val allSelects = Helpers.readResourceFiles("TOC_Resources/Member_Out_Insert,txt")
    val selectColumns =  allSelects.map(x => x.split("|")).
      filter(x => !x.isEmpty && x(0) == lob).flatMap(x => x(1).split(","))
    .map(x => {
      if(x.trim == "'final_file_name'")
        s"'${fileName.trim}'"
      else
        x.trim
    })

    val memberOutViewDF = sparkSession.read.table(s"$memberOutViewDBName.$memberOutViewName")
    val maxRecInsrt_TS = memberOutViewDF.agg(max("REC_INSRT_TS")).head().getAs[Int](0)

    val lobDF = sparkSession.read.table(s"$lobHiveDBName.$lobHiveTableName")
    val recentDataDF = lobDF.where($"REC_INSRT_TS" === maxRecInsrt_TS )
    val joinDF = memberOutViewDF.alias("B").join(recentDataDF.alias("A"), $"B.sub_ID" === $"A.sub_id")
    val member_out_select_df = joinDF.selectExpr(selectColumns:_*)

    sparkSession.conf.set("hive.exec.dynamic.partition", "true")
    sparkSession.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")

    member_out_select_df.write.mode("append").insertInto(s"$memberOutDBName.$memberOutTableName")
  }

}
