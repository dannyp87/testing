package DrugclmFullExtracts

import Utilities.{FixFileReader, Helpers}
import org.apache.spark.sql.functions.{input_file_name, size, split}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MCEFExtracts {


  def getMCEFDF(spark:SparkSession, basePath: String, startDate: String, endDate: String) = {

    import spark.implicits._
    val mcefAllFiles = Helpers.getFolderNamesBetweenDates(basePath, startDate, endDate)
    //val mcefAllFiles = List("C:\\Users\\krajkumar\\Desktop\\HCSC\\TOC\\Phatrmacy\\spark\\mcefdata.txt")
    val filxFileReader = new FixFileReader()
    val mcefDf = filxFileReader.readFiexedFilePatter(mcefAllFiles, "TOC_Resources/MCEF_File_Pattern.txt", spark)
    mcefDf
  }


  def readDrug_Clm_SelectStatements(path:String) = {
    val data = Helpers.readResourceFiles(path)
    data.filter(x => x.trim != "")
  }

}
