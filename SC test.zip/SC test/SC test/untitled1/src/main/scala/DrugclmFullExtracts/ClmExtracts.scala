package DrugclmFullExtracts

import Utilities.{HDFSHelper, Helpers}
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

object ClmExtracts {

  def extractFiles(spark:SparkSession, export_flag:String, config: Config): Unit = {
    val drug_clm_db = config.getString("Drug_clm_DB")
    val drug_clm_table = config.getString("Drug_clm_Table")
    val drug_clm_df = spark.read.table(s"$drug_clm_db.$drug_clm_table")
    val currentDate = Helpers.getCurrentDateTime("yyyy-MM-dd-hh-mm-ss")

    if(export_flag == "P" || export_flag == "PW") {
      val HDFSTempDir_P = config.getString("Export_HDFS_TEMP_DIR_P")
      val HDFSDir_P = config.getString("Export_HDFS_DIR_P")
      val lfsDir = config.getString("Export_LFS_DIR_P")
      val lfsfilePath=s"$lfsDir/$currentDate.txt"

      val filter_drug_clm = drug_clm_df.where("xfer_mco_id = 'P'")
      filter_drug_clm.write.mode("overwrite").option("sep", "|").option("header","flase").csv(HDFSTempDir_P)

      HDFSHelper.mergeFilesToLFS(s"$HDFSTempDir_P/*", lfsfilePath)
      HDFSHelper.copyFilesToHDFS(lfsfilePath, HDFSDir_P)
    }
    if(export_flag == "W" || export_flag == "PW"){
      val HDFSTempDir_W = config.getString("Export_HDFS_TEMP_DIR_W")
      val HDFSDir_W = config.getString("Export_HDFS_DIR_W")
      val lfsDir = config.getString("Export_LFS_DIR_W")
      val lfsfilePath=s"$lfsDir/$currentDate"

      val filter_drug_clm = drug_clm_df.where("xfer_mco_id = 'W'")
      filter_drug_clm.write.mode("overwrite").option("sep", "|").option("header","flase").csv(HDFSTempDir_W)

      HDFSHelper.mergeFilesToLFS(s"$HDFSTempDir_W/*", lfsfilePath)
      HDFSHelper.copyFilesToHDFS(lfsfilePath, HDFSDir_W)
    }
    else{

    }
  }

  def commonExtraction(spark:SparkSession, export_flag:String, config: Config, lob:String) = {

    val lobConfig = config.getConfig(lob)

    val db = lobConfig.getString("DB")
    val table = lobConfig.getString("TABLE")
    val extractColumns = lobConfig.getString("SELECT_COLUMNS").split(",").map(_.trim)

    val tableDF = spark.read.table(s"$db.$table")
    tableDF.count()
    val currentDate = Helpers.getCurrentDateTime("yyyy-MM-dd-hh-mm-ss")

    if(export_flag == "P" || export_flag == "PW") {
      val HDFSTempDir_P = lobConfig.getString("Export_HDFS_TEMP_DIR_P")
      val HDFSDir_P = lobConfig.getString("Export_HDFS_DIR_P")
      val lfsDir = lobConfig.getString("Export_LFS_DIR_P")
      val lfsfilePath=s"$lfsDir/$currentDate.txt"

      val filter_drug_clm = tableDF.where("trim(xfer_mco_code) = 'P'")
      val select_columns_DF = filter_drug_clm.selectExpr(extractColumns:_*)
      select_columns_DF.write.mode("overwrite").option("sep", "|").option("header","false").csv(HDFSTempDir_P)

      HDFSHelper.mergeFilesToLFS(s"$HDFSTempDir_P/*", lfsfilePath)
      HDFSHelper.copyFilesToHDFS(lfsfilePath, HDFSDir_P)
    }

    if(export_flag == "W" || export_flag == "PW"){
      val HDFSTempDir_W = lobConfig.getString("Export_HDFS_TEMP_DIR_W")
      val HDFSDir_W = lobConfig.getString("Export_HDFS_DIR_W")
      val lfsDir = lobConfig.getString("Export_LFS_DIR_W")
      val lfsfilePath=s"$lfsDir/$currentDate"

      val filter_drug_clm = tableDF.where("trim(xfer_mco_code) = 'W'")
      val select_columns_DF = filter_drug_clm.selectExpr(extractColumns:_*)
      select_columns_DF.write.mode("overwrite").option("sep", "|").option("header","false").csv(HDFSTempDir_W)

      HDFSHelper.mergeFilesToLFS(s"$HDFSTempDir_W/*", lfsfilePath)
      HDFSHelper.copyFilesToHDFS(lfsfilePath, HDFSDir_W)
    }
  }
}
