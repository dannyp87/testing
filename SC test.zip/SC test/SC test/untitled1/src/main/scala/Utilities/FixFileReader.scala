package Utilities


import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

import scala.io.Source

class FixFileReader extends Serializable {

  def readFiexedFilePatter(sourceFilePath:List[String], resourceFilePath:String, spark:SparkSession) : Dataset[Row] = {

    val fixedFilePattern = readResourceFiles(resourceFilePath)
    val df = getDataFrame(sourceFilePath, spark, fixedFilePattern)
    df
  }

  def getRow(row: String, allSchema: List[FiexedPattern]): Row = {
    val columns: scala.collection.mutable.ArrayBuffer[String] = new scala.collection.mutable.ArrayBuffer[String]()
    allSchema.foreach(x => {
      columns.append(row.substring(x.startIndex - 1, x.endIndex).trim())
    })

    Row.fromSeq(columns)
  }

  def readResourceFiles(fileName: String): List[String] = {
    val fileStream = getClass.getResourceAsStream(s"/$fileName")
    val lines = Source.fromInputStream(fileStream).getLines.toList
    lines
  }

  def getDataFrame(filePaths: List[String], spark: SparkSession, allColumnsRanges:List[String]): DataFrame = {

    import spark.implicits._

    val allSchema = allColumnsRanges.filter(x => !x.equals("") && !x.trim.startsWith("--")).
      map(x => {
      val fixData = x.trim.split(",")
      FiexedPattern(fixData(0).trim, fixData(1).trim.toInt, fixData(2).trim.toInt)
    }).toList

    val fields = allSchema
      .map(field => StructField(field.columnName, StringType, true))
    val schema = StructType(fields)

    val ds = spark.read.textFile(filePaths: _*)
    val allRows = ds.rdd.map(x => getRow(x, allSchema))
    val df = spark.createDataFrame(allRows, schema)
    df
  }
}

case class FiexedPattern(columnName:String, startIndex:Int,endIndex:Int)