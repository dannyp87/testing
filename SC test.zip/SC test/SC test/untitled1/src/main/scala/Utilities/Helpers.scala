package Utilities

import com.typesafe.config.{Config, ConfigFactory}

import scala.io.Source

object Helpers {

  def readConfig(path: String, lob: String): Config = {
    val allConfig = ConfigFactory.parseResources(path)
    val fullConfig = allConfig.getConfig(s"$lob")
    fullConfig
  }

  def readConfig1(path: String): Config = {
    val allConfig = ConfigFactory.parseResources(path)
    allConfig
  }


  def getCurrentDateTime(FORMAT:String) : String = {
    val dateFormat = new java.text.SimpleDateFormat(FORMAT)
    dateFormat.format(new java.util.Date())
  }

  def readResourceFiles(fileName: String): List[String] = {
    val fileStream = getClass.getResourceAsStream(s"/$fileName")
    val lines = Source.fromInputStream(fileStream).getLines.toList
    lines
  }

  def getFolderNamesBetweenDates(basePath: String, startDate: String, endDate: String): List[String] = {
    val allFolders: scala.collection.mutable.ArrayBuffer[String] = new scala.collection.mutable.ArrayBuffer[String]()
    val dateFormat = new java.text.SimpleDateFormat("yyyy/MM/dd")
    val modifiedFromDate = startDate; // need to change start date format to yyyy/MM/DD
    val modifiedLastDate = endDate
    val MILLIS_IN_DAY = 1000 * 60 * 60 * 24

    val nextDate = (currentDate: java.util.Date) => dateFormat.format(currentDate.getTime + MILLIS_IN_DAY)
    val previousDate = (currentDate: java.util.Date) => dateFormat.format(currentDate.getTime - MILLIS_IN_DAY)

    val dateSelectedFrom = dateFormat.parse(modifiedFromDate)
    val dateSelectedTo = dateFormat.parse(modifiedLastDate)
    var currentDate = dateSelectedFrom

    while (currentDate.compareTo(dateSelectedTo) != 1) {
      allFolders.append(basePath + "/" + dateFormat.format(currentDate))
      currentDate = dateFormat.parse(nextDate(currentDate))
      println(currentDate)
    }
    allFolders.toList
  }

}
