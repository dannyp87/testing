package Utilities

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import sys.process._
object HDFSHelper {

  def copyFilesToHDFS(srcFilePath:String, destFilePath:String): Unit = {
    val hadoopConf = new Configuration()
    val hdfs = FileSystem.get(hadoopConf)

    val srcPath = new Path(srcFilePath)
    val destPath = new Path(destFilePath)

    hdfs.copyFromLocalFile(srcPath, destPath)
  }

  def copyFilesToLFS(srcFilePath:String, destFilePath:String): Unit = {
    val hadoopConf = new Configuration()
    val hdfs = FileSystem.get(hadoopConf)

    val srcPath = new Path(srcFilePath)
    val destPath = new Path(destFilePath)

    hdfs.copyToLocalFile(srcPath, destPath)
  }

  def mergeFilesToLFS(hdfsSrcFolder:String, lfsDestFile:String): Unit = {

    val cmd = s"hdfs dfs -getmerge $hdfsSrcFolder $lfsDestFile".!
    if(cmd == 0)
      println(s"The source File in HDFS $hdfsSrcFolder is successfully merged to $lfsDestFile.")
    else
      println(s"The source File in HDFS $hdfsSrcFolder is unable to merge to $lfsDestFile.")
  }
}
